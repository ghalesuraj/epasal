<div id="springoo-dokan-seller-listing">
	<?php
	//phpcs:disable
	$template = apply_filters('springoo_dokan_template_style', (int) springoo_get_mod( 'dokan_template_style' ));
	include_once SPRINGOO_THEME_DIR . 'dokan/store-template-' . $template . '.php';
	//phpcs:enable
	?>
</div>
